import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

class NativeChannelUtil {
  // Android原生View 在Flutter引擎上注册的唯一标识，在Flutter端使用时必须一样
  static const String channelName = "flutter.leon.example/method_channel";

  // Flutter端 向 Android端 发送数据
  static const String flutterSendAndroidDataNotice =
      "flutterSendAndroidDataNotice";

  // Flutter端 获取 Android端 数据
  static const String flutterGetAndroidDataNotice =
      'flutterGetAndroidDataNotice';

  // Android端 向 Flutter端 发送数据
  static const String androidSendFlutterDataNotice =
      'androidSendFlutterDataNotice';

  // Android端 获取 Flutter端 数据
  static const String androidGetFlutterDataNotice =
      'androidGetFlutterDataNotice';

  String msgState = "默认消息";
  late MethodChannel mChannel;

  ///初始化消息通道
  void initChannel() {
    // 创建 Flutter端和Android端的，相互通信的通道
    mChannel = const MethodChannel(channelName);
    // 监听来自 Android端 的消息通道
    // Android端调用了函数，这个handler函数就会被触发
    mChannel.setMethodCallHandler(_handler);
    debugPrint("初始化initChannel");
  }

  /// 监听来自 Android端 的消息通道
  /// Android端调用了函数，这个handler函数就会被触发
  Future<dynamic> _handler(MethodCall call) async {
    //根据调用函数名称进行相应处理
    final methodName = call.method;
    switch (methodName) {
      case androidSendFlutterDataNotice:
        debugPrint("触发了---androidSendFlutterDataNotice");
        break;
      case androidGetFlutterDataNotice:
        debugPrint("触发了---androidGetFlutterDataNotice");
        break;
      case flutterSendAndroidDataNotice:
        debugPrint("触发了---flutterSendAndroidDataNotice");
        break;
      case flutterGetAndroidDataNotice:
        debugPrint("触发了---flutterGetAndroidDataNotice");
        break;
      default:
        {
          return PlatformException(
              code: '-1',
              message: '未找到Flutter端具体实现函数',
              details: '具体描述'); // 返回给Android端
        }
    }
  }

  // Flutter端向Android端发送数据，put操作
  flutterSendAndroidData() {
    final map = {flutterSendAndroidDataNotice, "我是flutter向android端发来的数据"};
    mChannel.invokeMethod(flutterSendAndroidDataNotice, map).then((value) {
      debugPrint("Flutter端向Android端发送数据---发送结果：$value");
    }).catchError((e) {
      if (e is MissingPluginException) {
        debugPrint(
            '$flutterSendAndroidDataNotice --- Error：notImplemented --- 未找到Android端具体实现函数');
      } else {
        debugPrint('$flutterSendAndroidDataNotice --- Error：$e');
      }
    });
  }

  // Flutter端获取Android端数据，get操作
  flutterGetAndroidData() {
    // Android端调用Result相关回调函数后，then、catchError 会接收到
    mChannel.invokeMethod(flutterGetAndroidDataNotice).then((value) {
      debugPrint("从android端获取的信息:$value");
    }).catchError((e) {
      if (e is MissingPluginException) {
        debugPrint(
            '$flutterGetAndroidDataNotice --- Error：notImplemented --- 未找到Android端具体实现函数');
      } else {
        debugPrint('$flutterGetAndroidDataNotice --- Error：$e');
      }
    });
  }
}
