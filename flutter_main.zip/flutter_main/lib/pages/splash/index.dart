library splash;

export './controller.dart';
export './view.dart';
export './router.dart';