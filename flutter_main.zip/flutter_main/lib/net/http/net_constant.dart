class NetConstant {
  static const String API_TOKEN =
      "JAuD4i3CudKhe2jQg8J/DkEghIE5ds00KBv7XSMTxVnFUDZj5arnHhg6en0oZJOdQdVNBnn22GJ2QPFeyy1SP1oo5uHiu3YISj4VgHZ/B9wpyT36ybVQdv3RRV+AcUoL7FgqBIVEN9H/5N5V119GgUNyqX7wm8gmXTYdPki4z0QVQei1Ba1bjjCHhRbCDPG8lNRJ+NV6AACwQLdODzpgEbSXE3fkc+8NOapU7CSnflEK8rjg9TAcP2pJA2oeepL6";
  static const String Request_TOKEN =
      "eyJhbGciOiJIUzI1NiJ9.eyJqdGkiOiJmYmYyZDdhNS1mMjg2LTRhNTUtYTc1Yi00YTlhZmQ3OGFhMDciLCJpYXQiOjE3MjY0NTE5ODMsInN1YiI6IntcInBsYXllcklkXCI6MTMyNzM4LFwibG9naW5OYW1lXCI6XCJiYmJiYnRyeXBsYXllcjAwMVwiLFwibmlja05hbWVcIjpcInRyeXBsYXllcjAwMVwiLFwiY3VycmVuY3lcIjpcIkNOWVwiLFwiY2F0ZWdvcnlcIjowLFwiYWdlbnRJZFwiOjJ9IiwiZXhwIjoxNzI2NDk1MTgzfQ.S1tGBBnKUxOkrt3lEiOyBOgt0y5_-pcG7mTxVqPs9D8";

  static const int CONNECT_TIMEOUT = 20 * 000;
  static const int RECEIVE_TIMEOUT = 3 * 000;
  static const String ACCEPT = "application/json,*/*";
  static const String CONTENT_TYPE = "application/json; charset=utf-8";

  /// 成功
  static const SUCCESS = 200;

  ///
  static const EXPIRED_TOKEN = 401;
}
