class TableBetPointDetail{
  int? playerId;
  int? betPointId;
  int? amount;
  int? player;

  TableBetPointDetail({
    this.playerId,
    this.betPointId,
    this.amount,
    this.player,
  });
}