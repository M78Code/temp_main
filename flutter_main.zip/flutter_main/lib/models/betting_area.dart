import 'dart:ui';

class BettingArea {
  Offset offsetArea = Offset.zero; //区域大小
  Offset offsetCoordinate = Offset.zero; //区域坐标  就是控件的左上角坐标
  BettingArea({required this.offsetArea, required this.offsetCoordinate});
}
