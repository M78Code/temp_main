class AppSvgs {

  static const arrowBottom = "assets/images/userProfile/svgs/arrow_bottom.svg";

  static const editIcon = "assets/images/userProfile/svgs/edit.svg";
}