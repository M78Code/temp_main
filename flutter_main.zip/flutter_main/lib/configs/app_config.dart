import 'package:flutter/foundation.dart';

class AppConfig {
  static const bool isDebug = kDebugMode;
}