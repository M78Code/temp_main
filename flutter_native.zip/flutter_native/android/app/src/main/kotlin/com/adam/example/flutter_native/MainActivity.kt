package com.adam.example.flutter_native

import android.os.Bundle
import android.util.Log
import io.flutter.embedding.android.FlutterActivity
import io.flutter.embedding.engine.FlutterEngine
import io.flutter.plugin.common.MethodCall
import io.flutter.plugin.common.MethodChannel
import io.flutter.plugins.GeneratedPluginRegistrant

class MainActivity : FlutterActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
    }

    override fun configureFlutterEngine(flutterEngine: FlutterEngine) {
        super.configureFlutterEngine(flutterEngine)
        GeneratedPluginRegistrant.registerWith(flutterEngine)
        Log.i("xxx", "configureFlutterEngine执行了")

        MethodChannel(
            flutterEngine.dartExecutor,
            "flutter.leon.example/method_channel"
        ).setMethodCallHandler(object : MethodChannel.MethodCallHandler {
            override fun onMethodCall(
                call: MethodCall,
                result: MethodChannel.Result
            ) {
                val methodName = call.method
                Log.i("xxx", "call = $call, result = $result")
                if ("flutterSendAndroidDataNotice" == methodName) {
                    Log.i("xxx", "flutterSendAndroidDataNotice条件允许")
                }
            }
        })
    }
}
