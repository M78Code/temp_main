package com.adam.example.flutter_native;

import android.util.Log;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import io.flutter.plugin.common.BinaryMessenger;
import io.flutter.plugin.common.MethodCall;
import io.flutter.plugin.common.MethodChannel;

public class TestMethodChannel implements MethodChannel.MethodCallHandler {

    private MethodChannel mChannel;
    // Android原生View 在Flutter引擎上注册的唯一标识，在Flutter端使用时必须一样
    public static final String CHANNEL_NAME = "flutter.leon.example/method_channel";
    // Android端 向 Flutter端 发送数据
    public static final String ANDROID_SEND_FLUTTER_DATA_NOTICE = "androidSendFlutterDataNotice";
    // Android端 获取 Flutter端 数据
    public static final String ANDROID_GET_FLUTTER_DATA_NOTICE = "androidGetFlutterDataNotice";
    // Flutter端 向 Android端 发送数据
    public static final String FLUTTER_SEND_ANDROID_DATA_NOTICE = "flutterSendAndroidDataNotice";
    // Flutter端 获取 Android端 数据
    public static final String FLUTTER_GET_ANDROID_DATA_NOTICE = "flutterGetAndroidDataNotice";

    public void initChannel(BinaryMessenger messenger) {
        // 创建 Android端和Flutter端的，相互通信的通道
        // 通道名称，两端必须一致
        mChannel = new MethodChannel(messenger, CHANNEL_NAME);
        // 监听来自 Flutter端 的消息通道
        // Flutter端调用了函数，这个handler函数就会被触发
        mChannel.setMethodCallHandler(this);
    }


    /**
     * 监听来自 Flutter端 的消息通道
     *
     * @param call   A {@link MethodCall}. Android端 接收到 Flutter端 发来的 数据对象
     * @param result A {@link MethodChannel.Result} Android端 给 Flutter端 执行回调的接口对象
     */
    @Override
    public void onMethodCall(@NonNull MethodCall call, @NonNull MethodChannel.Result result) {
        if (FLUTTER_SEND_ANDROID_DATA_NOTICE.equals(call.method)) {
            // 回调结果对象
            // 获取Flutter端传过来的数据
            Object argument = call.arguments;

        } else if (FLUTTER_GET_ANDROID_DATA_NOTICE.equals(call.method)) {

        }
    }

    /**
     * Android端 向 Flutter端 发送数据，相当于 PUT 操作
     */
    private void androidSendFlutterData() {
        String msg = "我是来自Android的消息";
        mChannel.invokeMethod(ANDROID_SEND_FLUTTER_DATA_NOTICE, msg, new MethodChannel.Result() {
            @Override
            public void success(@Nullable Object result) {
                Log.i("aaa", "android给flutter发送消息成功: " + result);
            }

            @Override
            public void error(@NonNull String errorCode, @Nullable String errorMessage, @Nullable Object errorDetails) {
                Log.i("aaa", "android给flutter发送消息失败: " + "errorCode: " + errorCode + "errorMessage: " + errorMessage);
            }

            /**
             * Flutter端 未实现 Android端 定义的接口方法
             */
            @Override
            public void notImplemented() {
                Log.d("aaa", "notImplemented");
            }
        });
    }
}
