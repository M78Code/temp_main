package com.example.myapplication;

/**
 * Author: K
 * <p>
 * Date: 2024/11/18
 * <p>
 * Description: 描述下
 */
public class LoginBo {
    public String loginName;
    public String loginPassword;
    public String backurl;
    public int deviceType;
}
