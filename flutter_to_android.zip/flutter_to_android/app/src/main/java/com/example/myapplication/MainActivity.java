package com.example.myapplication;

import android.content.Intent;
import android.os.Bundle;

import com.blankj.utilcode.util.ActivityUtils;
import com.blankj.utilcode.util.GsonUtils;
import com.blankj.utilcode.util.LogUtils;
import com.blankj.utilcode.util.StringUtils;
import com.blankj.utilcode.util.ThreadUtils;
import com.google.android.material.snackbar.Snackbar;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.view.View;

import androidx.navigation.NavController;
import androidx.navigation.Navigation;
import androidx.navigation.ui.AppBarConfiguration;
import androidx.navigation.ui.NavigationUI;

import com.example.myapplication.databinding.ActivityMainBinding;

import android.view.Menu;
import android.view.MenuItem;
import android.widget.Button;
import android.widget.EditText;

import java.io.IOException;

import io.flutter.embedding.android.FlutterActivity;
import io.flutter.embedding.android.FlutterEngineProvider;
import io.flutter.embedding.engine.FlutterEngine;
import io.flutter.embedding.engine.FlutterEngineCache;
import io.flutter.embedding.engine.dart.DartExecutor;
import io.flutter.plugin.common.EventChannel;
import io.flutter.plugin.common.MethodCall;
import io.flutter.plugin.common.MethodChannel;
import io.flutter.plugins.GeneratedPluginRegistrant;
import io.flutter.view.FlutterMain;
import okhttp3.Call;
import okhttp3.MediaType;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;
import okhttp3.ResponseBody;


public class MainActivity extends AppCompatActivity {

    private static final String TAG = "--MainActivity--";

    private static final String BASE_URL = "https://gateway.dpzrfat6.com/";

    private AppBarConfiguration appBarConfiguration;
    private ActivityMainBinding binding;

    private EditText userName;
    private EditText password;
    private Button loginBtn;
    private  EventChannel.EventSink eventSink;

    Intent activity;
    private FlutterEngine flutterEngine;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        flutterEngine = new FlutterEngine(this);
        flutterEngine.getDartExecutor().executeDartEntrypoint(
                DartExecutor.DartEntrypoint.createDefault()
        );
        FlutterEngineCache.getInstance().put("com.dp.flutter_main", flutterEngine);
        GeneratedPluginRegistrant.registerWith(flutterEngine);
//        activity = FlutterActivity.createDefaultIntent(getApplicationContext());

         new EventChannel(flutterEngine.getDartExecutor(), "native_to_flutter").setStreamHandler(new EventChannel.StreamHandler() {
            @Override
            public void onListen(Object arguments, EventChannel.EventSink events) {
                eventSink = events;
            }

            @Override
            public void onCancel(Object arguments) {

            }
        });

//         new MethodChannel(flutterEngine.getDartExecutor(), "flutter_to_Native").setMethodCallHandler(new MethodChannel.MethodCallHandler() {
//             @Override
//             public void onMethodCall(@NonNull MethodCall call, @NonNull MethodChannel.Result result) {
//
//                 LogUtils.dTag(TAG,"onMethodCall-call.method=");
//                 if (call.method.equals("flutterBackToNative")) {
//                     //添加 activity 退出函数；
////                     flutterEngine.destroy();
//                 }
//             }
//         });

//        new MethodChannel(flutterEngine.getDartExecutor().getBinaryMessenger(), "flutter_to_Native").setMethodCallHandler(
//                (call, result) -> {
//                    LogUtils.dTag(TAG,"onMethodCall-call.method=");
//                    if (call.method.equals("flutterBackToNative")) {
//                        finish();
//                    } else {
//                    }
//                }
//        );

        binding = ActivityMainBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        loginBtn = findViewById(R.id.btn_login);
        userName = findViewById(R.id.ET_userName);
        password = findViewById(R.id.ET_password);

        loginBtn.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v) {

                LoginBo loginBo = new LoginBo();
                loginBo.loginName = userName.getText().toString();
                loginBo.loginPassword = password.getText().toString();
                loginBo.backurl = BASE_URL + "#/?login=true";
                loginBo.deviceType = 1;

                goLogin(loginBo);
//                eventSink.success("https://pc.dpzrfat6.com/?params=Y3smmkLZKTT5wVuPO7uf35BFnLbB3MUbdSu2cUoOJ28IbJW7k1yCKHxmvtMTafBons8nCQKsaRb1byowQwI8uF/0fevVllHw6N8o8/K9vzJxZ1PFgrY//v0EV9UPSqg+JFWWmehPuzQsLeSxBqfdJ5HjxXv1CVYyx2rBvdN7vmSNH2OY165HK5xLqe/fLamXHJk6LReoYnpTMniGQnGGKJywJeZ099mTyRk+q2aAdIYLOqoAz4//xkhwkpk41ql3SiHRy3zk8RaN/FwkTzNVvMwPeyJMCl04Q+z98ZCdJ8T6mvCdaLvVTZMvSrSB96u056E9WomyWypUEOSmuPaUf43U8ZS5NUj7VqIAJaphC9ZMxtCh3wkVjCc4ct4fI3bR/YSPJAlxJbRvgH4R1mrP2AFMA+1rWVGdPOj1cGR4EVHC62EIQwqwwjQhYHmKddcGl+OnscdQLaB/XTR9CWdyhBgc8ptWjmHPhGfQkIySXUrW67Kb57brxtCLasMXQ9yf5EyvsrfkJ8y4FGjbUt4qZRw+/4A75Qac7b96XzL1WUFmK1WsCAR99dm071LT7Tw+uUojCFXvUlzx0yV/Uoxq9QwMAXivWfwAzlvLC+iP+frZlXHvxg6b+bv0RezXMD15lhWQ0SzeR41DcDPEYtOXDco+1p2VB7QNkaTHroBwDiYz0vpDP8yWhCl4/y5rDmaDIFu19NS8BQEyy8wxCHXVKUBluBZ/5r1kwCXkvGK+7kEnj/yGYWl4KZrEJGmmxDhwxeW9hiA1zJtEnTrOzEgJDFxCyJdUMXW1KsUZf1HswZZnSjxIN9MkXaVKZX/ciK0hyLdZ7rxgUIRiEHFabUI50gm3hDR/eTFb6kemNy4Eqm1XMXEP1yCLpPfQOsXy38GudXLv42Smu+1+pWjrxjsppRn2WuC5S1VqYYSvEx8M2q381orWiTc/EQ+KCduN1o0D6zZuKwyC7WMRARVZmUtOMJvt7Bz95f3lsyF25mMpi6h1AyAqFigfewDSVK52rFJZRoe90D2cbexo7YSm7YJIJzZ7j+BdEgSZI1uPuuew7KUi7HmhEPSJV3VbQ+vtSGfnHxI2b8PuXXYrIkVA7yHOP4vHbrtYzvSK0G1XEcnyJbE7rbNL0Ep9mBamvmX3HgOdBM5ghJTcILAosj59uI4LL3epaI3erz0ev1pl/PcEYQQ/oO9kx0JGlfoPZBkHU+2ZJNplpcfF1rtCT8gZuVhs7TwaD2ehvfV9rk5/ewe3I4efJtdCMyA+8yO6ZoNhXlCP&signature=F7D3B222BE2BE62458EB6F22D5879D87&ttl=1731763304899");
//              startActivity(activity);

            }
        });





//        NavController navController = Navigation.findNavController(this, R.id.nav_host_fragment_content_main);
//        appBarConfiguration = new AppBarConfiguration.Builder(navController.getGraph()).build();
//        NavigationUI.setupActionBarWithNavController(this, navController, appBarConfiguration);

    }

//    @Override
//    public void configureFlutterEngine(@NonNull FlutterEngine flutterEngine) {
//        super.configureFlutterEngine(flutterEngine);
//        new MethodChannel(flutterEngine.getDartExecutor().getBinaryMessenger(), "flutter_to_Native").setMethodCallHandler(
//                (call, result) -> {
//                    LogUtils.dTag(TAG,"onMethodCall-call.method=");
//                    if (call.method.equals("flutterBackToNative")) {
//                        finish();
//                    } else {
//                    }
//                }
//        );
//    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
//        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
//        int id = item.getItemId();
//
//        //noinspection SimplifiableIfStatement
//        if (id == R.id.action_settings) {
            return true;
//        }
//
//        return super.onOptionsItemSelected(item);
    }

//    @Override
//    public boolean onSupportNavigateUp() {
////        NavController navController = Navigation.findNavController(this, R.id.nav_host_fragment_content_main);
////        return NavigationUI.navigateUp(navController, appBarConfiguration)
////                || super.onSupportNavigateUp();
//        return true;
//    }

    private void goLogin(LoginBo loginBo) {
        ThreadUtils.executeByIo(new ThreadUtils.SimpleTask<String>() {
            @Override
            public String doInBackground() throws Throwable {

                String responseData = "";

                String loginBoJson = GsonUtils.toJson(loginBo);

                RequestBody body = RequestBody.create(MediaType.parse("application/json"), loginBoJson);

                Request request = new Request.Builder()
                        .url(BASE_URL + "game-http/player/loginGame")
                        .post(body)
                        .build();

                Call call = new OkHttpClient().newCall(request);
                Response response = null;
                try {
                    response = call.execute();
                } catch (Exception e) {
                    LogUtils.dTag(TAG,"goLogin-execute failed, message:"+ e.getMessage());
                }

                assert response != null;
                if (response.isSuccessful()) {
                    responseData = response.body().string();
                    LogUtils.dTag(TAG,"goLogin-responseData="+responseData);
                } else {
                    LogUtils.dTag(TAG,"goLogin-response-failed");
                }
                return responseData;
            }

            @Override
            public void onSuccess(String result) {
                if (StringUtils.isEmpty(result)) {
                    LogUtils.dTag(TAG,"goLogin-onSuccess-result=null");
                } else {

                    LoginModel loginModel = GsonUtils.fromJson(result, LoginModel.class);

                    if (200 == loginModel.code && !StringUtils.isEmpty(loginModel.data)) {
                        eventSink.success(loginModel.data);
//                        startActivity(activity);
                        ActivityUtils.startActivity(GameFlutterActivity.class);
                    } else {
                        LogUtils.dTag(TAG,"goLogin-onSuccess-code != 200");
                    }
                }
            }
        });
    }

}