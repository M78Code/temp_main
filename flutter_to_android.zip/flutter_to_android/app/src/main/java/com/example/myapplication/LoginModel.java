package com.example.myapplication;

/**
 * Author: K
 * <p>
 * Date: 2024/11/18
 * <p>
 * Description: 描述下
 */
public class LoginModel {
    public String msg;
    public int code;
    public String data;
}
