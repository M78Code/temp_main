package com.example.myapplication;

import android.app.Application;

import com.blankj.utilcode.util.Utils;

/**
 * Author: K
 * <p>
 * Date: 2024/11/18
 * <p>
 * Description: 描述下
 */
public class MyApplication extends Application {

    @Override
    public void onCreate() {
        super.onCreate();

        Utils.init(this);
    }
}
