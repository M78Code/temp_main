package com.example.myapplication;

import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import io.flutter.embedding.android.FlutterActivity;
import io.flutter.embedding.engine.FlutterEngine;
import io.flutter.plugin.common.MethodChannel;

/**
 * <p>
 * Date: 2024/11/18
 * <p>
 * Description: 描述下
 */
public class GameFlutterActivity extends FlutterActivity {

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    @Override
    public void configureFlutterEngine(@NonNull FlutterEngine flutterEngine) {
        super.configureFlutterEngine(flutterEngine);

        MethodChannel methodChannel = new MethodChannel(flutterEngine.getDartExecutor(), "flutter_to_Native");
        methodChannel.setMethodCallHandler((call, result) -> {
            if (call.method.equals("flutterBackToNative")) {
                //添加 activity 退出函数；
                finish();
            }
        });
    }
}
